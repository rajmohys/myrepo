<div class="container">
	<div class="row">
		<div class="col-sm-3" style="margin-left:50px;margin-bottom:50px">
			<h1 style="margin-left:50px">Condition</h1>
			<p>creating an e commerce website with godaddy online store 
			is simple.create a site that a unique as your business.
			now that i have launch my own product line.I need a simple yet effective solution 
			for an online store.creating an e commerce website with godaddy online store 
			is simple.create a site that a unique as your business.
			now that i have launch my own product line.I need a simple yet effective solution 
			for an online store.</p>
		</div>
		
		<div class="col-sm-3" style="margin-left:50px">
			<h1 style="margin-left:50px">Resourses</h1>
			<p>creating an e commerce website with godaddy online store 
			is simple.create a site that a unique as your business.
			now that i have launch my own product line.I need a simple yet effective solution 
			for an online store.creating an e commerce website with godaddy online store 
			is simple.create a site that a unique as your business.
			now that i have launch my own product line.I need a simple yet effective solution 
			for an online store.</p>
		</div>
		<div class="col-sm-3" style="margin-left:50px">
			<h1 style="margin-left:50px">Facilities</h1>
			<p>creating an e commerce website with godaddy online store 
			is simple.create a site that a unique as your business.
			now that i have launch my own product line.I need a simple yet effective solution 
			for an online store.creating an e commerce website with godaddy online store 
			is simple.create a site that a unique as your business.
			now that i have launch my own product line.I need a simple yet effective solution 
			for an online store.</p>
		</div>
	</div>
</div>
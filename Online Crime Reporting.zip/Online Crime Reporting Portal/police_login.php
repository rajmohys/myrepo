<?php 
extract($_POST);
if(isset($submit))
{
	$que=mysqli_query($con,"select * from police_officer where user_alias='$user_name' and password='$pass'");
	
	$row=mysqli_num_rows($que);
	$data1=mysqli_fetch_assoc($que);
	if($row)
	{
		if($data1['status']==false)
		{
		echo "<script>window.location='Police_officer'</script>";
		 $_SESSION['logged_in']=$user_name;
		 $_SESSION['data']=$data1;
		}
		else
		{
		$err="<font color='red'>Your account is deactivated</font>";
		}
		 
	}
	else
	{
	$err="<font color='red'>Wrong login details</font>";
	}
}
?>
<form method="post">
<div class="container " style="margin-left:200px">
<h3 style="text-decoration:underline;"><font color="gray">Police Officer Login Form</font></h3>
<div class="row" style="margin-top:10px">
		<div class="col-sm-1"></div>
		<div class="col-sm-3"><?php echo @$err; ?></div>
	</div>
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">User Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" value="<?php echo @$user_name; ?>" placeholder="enter your user name" name="user_name" class="form-control"/>
			</div>
		</div>
	</div>
	
	<div class="row" style="margin-top:10px">
		
		<div class="col-sm-2">
			<label style="font-size:16px"> Password</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="password"  value="<?php echo @$pass; ?>" placeholder="enter your password" name="pass" class="form-control"/>
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:30px;margin-bottom:60px">
		<div class="col-sm-2"></div>
		<input type="submit" name="submit" value="Login" class="btn btn-info"/>
	</div>
	
</div>
</form>
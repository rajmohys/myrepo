<?php
extract($_POST);
if(isset($submit))
{
$que=mysqli_query($con,"select * from police_officer where email='".$arr['email']."' and password='$op'");
$r=mysqli_num_rows($que);


	if($r)
	{
		if($np!=$cp)
		{
			$err="<font color='red'>new password not euqal to confirm passowrd</font>";
		}
		else
		{
mysqli_query($con,"update police_officer  set password='$cp' where email='".$arr['email']."' ");
		$err="<font color='green'>Password Updated Successfully</font>";
		}
	}
	else
	{
	$err="<font color='red'>Wrong old password</font>";
	
	}
	

}
?>
<form method="post">
<table border="0" bgcolor="#99FFCC" style="margin:30px;">
<tr>
	 <th><?php echo @$err; ?></th>
</tr>
	
<tr>
	<th height="87">Old Password:  
    <input type="password" name="op" placeholder="enter your old password" class="form-control"/> </th>
</tr>
	
<tr>
	<th height="93">New Password:
    <input type="password" name="np"  placeholder="enter your new password" class="form-control" /> <br /></th>
</tr>
 <tr>
	<th height="93">Confirm Password:
    <input type="password" name="cp" placeholder="enter your confirm password" class="form-control" /> <br /></th>
</tr>

<tr>
	<th rowspan="2"><input type="submit" value="Update Password" name="submit" class="btn btn-success"/></th>
</tr>
</table>
</form>

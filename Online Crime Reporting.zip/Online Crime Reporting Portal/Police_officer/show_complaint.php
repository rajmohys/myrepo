<?php 
$q=mysqli_query($con,"select * from complaints where police_station='".$_SESSION['data']['police_station']."'");

$r=mysqli_num_rows($q);
if($r==false)
{
echo "<h2 style='color:Red'>No any Complaints for you</h2>";
}
else
{

?>
<div class="row">
	<div class="col-sm-12" style="color:orange;">
		<h1 align="center" >Complaints Details</h1>
	</div>
</div>
<div class="row">

<div class="col-sm-12">

<table class="table table-bordered">

	<thead >
	<tr  class="success">
		<th>S.No</th>
		<th>Subject</th>
		<th>Details</th>
		<th>Crime Type</th>
		<th>Crime Date</th>
		<th>Offender Name</th>
		<th>Offender Add</th>
		<th>Proof</th>
		<th>Witness</th>
		<th>User</th>
		<th>IP </th>
		<th>Update Status</th>
		</tr>
		</thead>
		
		<?php

		$i=1;
		while($row=mysqli_fetch_assoc($q))
		{
			echo "<tr>";
			echo "<td>".$i."</td>";
			echo "<td>".$row['subject']."</td>";
			echo "<td>".$row['details']."</td>";
			echo "<td>".$row['crime_type']."</td>";
			echo "<td>".$row['crime_date']."</td>";
			echo "<td>".$row['Offender_name']."</td>";
			echo "<td>".$row['Offender_address']."</td>";
			echo "<td>".$row['proof_documents']."</td>";
			echo "<td>".$row['witness_name']."</td>";
			echo "<td>".$row['user']."</td>";
			echo "<td>".$row['ip_address']."</td>";
			echo "<td><a href='index.php?info=display_complaint_status&compaint_id=".$row['id']."'>Status</a></td>";
			echo "</tr>";
			$i++;
		}
		
		?>
		
		
		
</table>
</div>
</div>
<?php } ?>
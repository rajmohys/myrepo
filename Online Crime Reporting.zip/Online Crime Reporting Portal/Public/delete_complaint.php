<?php 
require('../dbconfig.php');
mysqli_query($con,"delete from complaints where id='".$_GET['id']."'");
header('location:index.php?info=show_complaint');
?>
<?php
session_start(); 
$email=$_SESSION['user'];
require('../dbconfig.php');
if($email=="")
{
header('location:../index.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Public Dashboard</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../css/metisMenu.min.css" rel="stylesheet">

    
    <!-- Custom CSS -->
    <link href="../css/sb-admin-2.css" rel="stylesheet">


    <!-- Custom Fonts -->
    <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="userdashboard.php">Welcome <?php //echo $_SESSION['user']; 
				$arr=$_SESSION['data'];
				
				
				echo $arr['name']."<br>";
					//echo $arr['father_name']?></a>
				
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li>
						<a href="index.php?info=profile_update"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="index.php?info=update_password"><i class="fa fa-gear fa-fw"></i>Change Password</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                         <img src="../images/<?php echo $email?>/<?php echo $arr['image'];?>" alt="img not found" height="100px" width="100px" class="img-circle" style="margin-left:70px"/>
						 </li>
                       
 						<li>
                            <a href="#"><i class="fa fa-dashboard fa-fw"></i>User Dashboard</a> 
						</li>
                       
                                                   
                                 <li>
                                    <a href="index.php?info=add_complaint"><i class="fa fa-pencil fa-fw"></i>Add_Complaint</a>                                </li>
									
								
								 <li>
                                    <a href="index.php?info=show_complaint"><i class="fa fa-pencil fa-fw"></i>show_Complaint</a>                                </li>
									
							<li>
                                    <a href="index.php?info=feedback"><i class="fa fa-pencil fa-fw"></i>Give Feedback</a>                                </li>		
								
								
                                                                                              
							</ul>
							
							
                            <!-- /.nav-second-level -->
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                   
                	<?php 
								@$id=$_GET['id'];
								@$info=$_GET['info'];
								if($info!="")
								{	
									
									if($info=="update_password")
									{
										include('update_password.php');
									}
									if($info=="profile_update")
									{
										include('profile_update.php');
									}
									
									
									if($info=="add_complaint")
									{
										include('add_complaint.php');
									}
									if($info=="feedback")
									{
										include('feedback.php');
									}
									
									if($info=="show_complaint")
									{
										include('show_complaint.php');
									}
									
									if($info=="display_complaint_status")
									{
										include('display_complaint_status.php');
									}
									
									
									
								}
								else
								{

								include('show_complaint.php');
								}
								
							
							?>
				
				</div>
                <!-- /.col-lg-12 -->
            </div>
            
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../css/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../css/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../css/metisMenu.min.js"></script>

  
    <!-- Custom Theme JavaScript -->
    <script src="../css/sb-admin-2.js"></script>

</body>

</html>

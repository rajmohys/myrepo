<?php 
error_reporting(1);
$user=$_SESSION['user'];
extract($_POST);
if(isset($submit))
{			
	$que=mysqli_query($con,"select * from complaints where user='$user' and subject='$subj'");
	
	$row=mysqli_num_rows($que);
	if($row)
	{
	$err= "<font color='red'>This Complaint already Registered</font>";
	}
	else
	{
	$ip=$_SERVER['REMOTE_ADDR'];
	$query="insert into complaints values('','$crime_type','$crime_date','$subj',
                '$details','$Offender_name','$Offender_details','$document','$witness_name','$police_station','$user','$ip',now())";
				mysqli_query($con,$query);
				
				$err= "<font color='blue'>Complaint successfully filed. Your personal details / identity will be kept confidential. Pl. watch this page after 3 days for knowing the status of action taken</font>";

	
 
}
}
?>

		<form method="post" enctype="multipart/form-data">
		<div class="container" style="margin-left:100">
			
			
			
			<div class="row" style="margin-top:20px">
				<div class="col-sm-7"><?php echo @$err;?></div>
			</div>
			
			
			<div class="row" style="margin-top:10px">
				
				<div class="col-sm-2">
					<label style="font-size:16px">Type of Crime</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<select name="crime_type" class="form-control" required>
							<option>Robery</option>
							<option>Theft</option>
							<option>Murder</option>
							<option>Cheating</option>
							<option>Others</option>
						</select>
						
					</div>
				</div>
				<div class="col-sm-2">
					<label style="font-size:16px">Date of Crime</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="date" name="crime_date" class="form-control" required/>
					</div>
				</div>
			</div>
			
			
			
			<div class="row" style="margin-top:10px">
				
				<div class="col-sm-2">
					<label style="font-size:16px">Complaint subject</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="text" name="subj" name="complaint_subject" class="form-control" required/>
					</div>
				</div>
				<div class="col-sm-2" >
					<label style="font-size:16px">Complaint Details</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<textarea name="details" rows="5" cols="25" required></textarea>
					</div>
				</div>
			</div>
			
			
			<div class="row" style="margin-top:10px">
				
				<div class="col-sm-2">
					<label style="font-size:16px">Name of Offender</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="text" name="Offender_name" class="form-control"/>
					</div>
				</div>
				<div class="col-sm-2">
					<label style="font-size:16px">Last Name of Offender</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<input type="text" name="offence_last_name" class="form-control"/>
					</div>
				</div>
			</div>
			
			
			
			<div class="row" style="margin-top:10px">
				<div class="col-sm-2">
					<label style="font-size:16px">Address / Details of Offender</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<textarea name="Offender_details" rows="5" cols="25"></textarea>
					</div>
				</div>
				<div class="col-sm-2">
							<label style="font-size:16px;margin-top:30px">Names of witnesses</label>
						</div>
						<div class="col-sm-2" style="margin-top:30px">
						<input type="text" name="witness_name" class="form-control"/>	
						<?php /*?><select name="dd" class="form-control">
								<option selected="selected" disabled="disabled">dd</option>
								<?php
								for($i=1;$i<=31;$i++)
								{
									echo "<option>".$i."</option>";
								}
								?>
							</select>
						</div>
					
							<div class="col-sm-1" style="margin-top:30px">
							<select name="mm" class="form-control">
								<option selected="selected" disabled="disabled">mm</option>
								<?php
								$arr=array("jan","feb","march","april","may","june","july","aug","sep","oct","nov","dec");
								for($i=0;$i<count($arr);$i++)
								{
									echo "<option>".$arr[$i]."</option>";
								}
								?>
							</select>
						</div>
						<div class="col-sm-1" style="margin-top:30px">
							<select name="yy" class="form-control">
								<option selected="selected" disabled="disabled">yy</option>
								<?php
								for($i=1980;$i<=2016;$i++)
								{
									echo "<option>".$i."</option>";
								}
								?>
							</select><?php */?>	
					</div>
					
					
			</div>
			
			

			<div class="row" style="margin-top:10px">
			<div class="col-sm-2">
					<label style="font-size:16px">Select Police Station</label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						<select name="police_station" class="form-control" required>
							<?php
						$que1=mysqli_query($con,"select * from police_officer");
						while($r=mysqli_fetch_assoc($que1))
						{
						echo "<option>".$r['police_station']."</option>";
						}
							?>
						</select>
					</div>
				</div>
				<div class="col-sm-2">
					<label style="font-size:16px">Upload proof: document / photo (doc, pdf, jpg) </label>
				</div>
				<div class="col-sm-2">
					<div class="input-group">
						<input type="file" name="document" class="form-control"/>
					</div>
				</div>
				</div>
				
			<div class="row" style="margin-top:10px">
			<div class="col-sm-2">
					<label style="font-size:16px">
					<input type="checkbox" required></label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						I assure that the above complaint is true to the best of my knowledge.
					</div>
				</div>
			</div>
			
				<div class="row" style="margin-top:10px">
				<div class="col-sm-2">
					<label style="font-size:16px">
					<input type="checkbox" required></label>
				</div>
				<div class="col-sm-3">
					<div class="input-group">
						I assure that the above complaint is true to the best of my knowledge.
					</div>
				</div>
				
				
		
		
		
				
				
				
			
			
			<div class="row" style="margin-top:10px">
							
					
			</div>
			
					
						
			<div class="row" style="margin-top:10px">
						
			<div class="row" style="margin-top:20px;margin-bottom:60px">
				<div class="col-sm-3"></div>
				<input type="submit" name="submit" value="Register Complaint" class="btn btn-success"/>
			</div>
		</div>
		</form>
		
</head>
</html>

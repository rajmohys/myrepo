<?php 
$q=mysqli_query($con,"select * from complaint_status where compaint_id='".$_GET['compaint_id']."'");
$r=mysqli_num_rows($q);
if($r==false)
{
echo "<h3 style='color:Red'>Status not updated </h3>";
}
else
{
?>
<div class="row">
	<div class="col-sm-12" style="color:orange;">
		<h1 align="center" >Complaints Details</h1>
	</div>
</div>
<div class="row">

<div class="col-sm-12">

<table class="table table-bordered">

	<thead >
	
	<tr class="success">
		<th>Complaint Id</th>
		<th>Police Officer</th>
		<th>Status</th>
		<th>Date</th>
		</tr>
		</thead>
		
		<?php
	while($row=mysqli_fetch_assoc($q))
		{
			echo "<tr>";
			
			echo "<td>".$row['compaint_id']."</td>";
			echo "<td>".$row['police_officer']."</td>";
			echo "<td>".$row['statuss']."</td>";
			echo "<td>".$row['date']."</td>";
			echo "</tr>";
		}
		
		?>
		
		
		
</table>
</div>
</div>
<?php }?>
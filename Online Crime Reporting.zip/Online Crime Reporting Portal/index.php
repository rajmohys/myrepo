<?php
session_start();
 require('dbconfig.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<title>ONLINE CRIME REPORTING PORTAL</title>
	
	<!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="background:#000000">
        <div class="container" >
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php" style="color:#FFFFFF">ONLINE CRIME REPORTING PORTAL</a>
				
				
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    
					 <li style="color:#FFFFFF">
                        <a style="color:#FFFFFF" href="index.php"><i class="fa fa-home fa-fw"></i>Home</a>
                    </li>
					
					<!--<li style="color:#FFFFFF">
                        <a style="color:#FFFFFF" href="index.php?info=about"><i class="fa fa-home fa-fw"></i>About</a>
                    </li>-->
					
					<li><a style="color:#FFFFFF" href="index.php?info=registration"><i class="fa fa-gear fa-fw"></i>Registration</a></li>
				
				
								
	<li class="dropdown">
        <a style="color:#FFFFFF" href="#" class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-sign-in fa-fw"></i>Login
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          
          <li><a href="index.php?info=police_login">Police Officer</a></li>
          <li><a href="index.php?info=people_login">Citizen</a></li>
		   <li><a href="admin">Admin</a></li> 
        </ul>
      </li> 
	  
	  <li class="dropdown">
        <a style="color:#FFFFFF" href="#" class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-sign-in fa-fw"></i>Emergency
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          
          <li><a href="index.php?info=emergency_complaint">Emergency Complaint</a></li>
          <li><a href="index.php?info=emergency_complaint_status">Emergency Status</a></li>
		  
        </ul>
      </li> 
	  
	  
	 <li>
                        <a style="color:#FFFFFF" href="index.php?info=contact"><i class="fa fa-phone fa-fw"></i>Contact</a>
                    </li>
					 	
					
                    <li>
                        <a style="color:#FFFFFF" href="index.php?info=feedback"><i class="fa fa-copy fa-fw"></i>Feedback</a>
                    </li>
					
					<li>
                        <a style="color:#FFFFFF" href="index.php?info=news"><i class="fa fa-book fa-fw"></i>News Flash</a>
                    </li>
					
                   
					
	
					
					 
					
 


                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

<?php 
					@$info=$_GET['info'];
					if($info!="")
					{
											
						 if($info=="about")
						 {
						 include('about.php');
						 }
						 else if($info=="feedback")
						{
						include('feedback.php');
						}
						
						 else if($info=="emergency_complaint")
						{
						include('emergency_complaint.php');
						}
						
						 else if($info=="emergency_complaint_status")
						{
						include('emergency_complaint_status.php');
						}
						
						
						else if($info=="verify_otp")
						{
						include('verify_otp.php');
						}


						else if($info=="news")
						{
						include('news.php');
						}

						 
						 else if($info=="contact")
						 {
						 include('contact.php');
						 }
						
						 
						 else if($info=="people_login")
						 {
						 include('people_login.php');
						 }
						 
						 else if($info=="police_login")
						 {
						 include('police_login.php');
						 }
						 
						 
						 else if($info=="admin_login")
						 {
						 include('admin_login.php');
						 }
						 
						 
						 else if($info=="registration")
						 {
						 	include('registration.php');
						 }
					}
					else
					{
				?>
		<!-- slider start -->
    <header id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item active">
                
                <div class="fill" style="background-image:url('images/image1.jpg');"></div>
				<div class="carousel-caption">
                    
                </div>
            </div>
           
            <div class="item">
                <div class="fill" style="background-image:url('images/image3.jpg');"></div>
                <div class="carousel-caption">
                   
                </div>
            </div>
			
			 <div class="item">
                <div class="fill" style="background-image:url('images/crime_repor3.jpg');"></div>
                <div class="carousel-caption">
                   
                </div>
            </div>
			
			
			
			<div class="item">
				<div class="fill" style="background-image:url('images/image1.jpg');"></div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </header>
<!-- slider -->			
	
	
    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <div class="col-lg-12">
               
				
				
				
	
	
				
				
				
				<div class="panel  col-sm-6" style="margin-top:60px">
					<div class="panel-title bg-success text-center">
						FEATURED WEBSITES
					</div>
					<div class="panel-body">
							$1
							howtomakejuice.com
							$62
							AmateurElectronics.com
							$1
							LandscapingWorkers.com
							$50
							URL HIDDEN
							$50,000
							PittsburghSportingNews.com
							$550
							marylandhomework.com
							$1,100
							getrest.co
							$15
							WinCert.net
							$1,500
							TheGuamGuide.co
					
				<div class="panel-footer">
				</div></div>
			</div>
			
			<div class="panel  col-sm-6" style="margin-top:60px">
					<div class="panel-title bg-success text-center">
						FEATURED WEBSITES
					</div>
					<div class="panel-body">
							$1
							howtomakejuice.com
							$62
							AmateurElectronics.com
							$1
							LandscapingWorkers.com
							$50
							URL HIDDEN
							$50,000
							PittsburghSportingNews.com
							$550
							marylandhomework.com
							$1,100
							getrest.co
							$15
							WinCert.net
							$1,500
							TheGuamGuide.co
					
				<div class="panel-footer">
				</div></div>
			</div>
			
			
				<?php } ?>
            </div>
            
    </div>
    <!-- /.container -->
	
	<div class="navbar-fixed-bottom nav navbar-inverse text-center" style="padding:15px;height:40px;">
		<span style="color:#FFFFFF">Developed By ....... 	Rajmohan R </span>
	</div>
    <!-- jQuery -->
    <script src="css/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="css/bootstrap.min.js"></script>

    <!-- Script to Activate the Carousel -->
    <script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>

</body>

</html>

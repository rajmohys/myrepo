<?php
$con=mysqli_connect("localhost","root","","law_order")or die(mysqli_error());
?>
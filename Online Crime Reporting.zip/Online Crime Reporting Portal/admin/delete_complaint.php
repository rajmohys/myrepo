<?php
include('../dbconfig.php');
	
	$info=$_GET['id'];
	
	mysqli_query($con,"delete from complaints where id='$info'");
	header('location:dashboard.php?info=display_complaints');
?>
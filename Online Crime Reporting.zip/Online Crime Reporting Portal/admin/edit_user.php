<?php
$que=mysqli_query($con,"select * from police_officer where id='$id'");
$res=mysqli_fetch_array($que);
extract($_POST);
	if(isset($save))
		{
			mysqli_query($con,"update police_officer set name='$name',email='$email',mobile='$mob',police_station='$ps' where id='$id'");
			$err="<font color='green'>profile updated successfully !!</font>";
		}
?>
<h1 class="page-header">Edit user</h1>
<div class="col-lg-8" style="margin:15px;">
	<form method="post">
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label><?php echo @$err;?></label>
        </div>
   	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>User Name:</label>
            	<input type="text" name="name" class="form-control" value="<?php echo $res['Name'];?>" autofocus>
        </div>
   	</div>
 	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Email :</label>
            	<input type="email"  name="email" class="form-control"value="<?php echo $res['email'];?>">
        </div>
    </div>
                  
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Mobile Number:</label>
            	<input type="Text" class="form-control" name="mob" value="<?php echo $res['mobile'];?>">
        </div>
  	</div>
	
	<div class="control-group form-group">
    	<div class="controls">
        	<label>Police Station:</label>
  <input type="text"  name="ps" value="<?php echo $res['police_station'];?>" class="form-control" required>
        </div>
    </div>
	
	<div class="control-group form-group">
    	<div class="controls">
            	<input type="submit" class="btn btn-success" name="save" value="Update Record">
        </div>
  	</div>
	</form>


</div>
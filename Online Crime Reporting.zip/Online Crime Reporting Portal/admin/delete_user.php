<?php
include('../dbconfig.php');
	
	$info=$_GET['id'];
	
	mysqli_query($con,"delete from police_officer where id='$info'");
	header('location:dashboard.php?info=show_user');
?>
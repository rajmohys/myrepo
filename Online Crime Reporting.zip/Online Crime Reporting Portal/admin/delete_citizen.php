<?php
include('../dbconfig.php');
	
	$info=$_GET['id'];
	
	mysqli_query($con,"delete from people_registration where id='$info'");
	header('location:dashboard.php?info=display_citizen');
?>
<?php 
extract($_POST);
//print_r($_SESSION['data']);
if(isset($add))
{
$q=mysqli_query($con,"insert into emergencey_complaint_status values('','$c_id','$c_status','".$_SESSION['user']."',now())");
$err="<font color='green'>Complaint Staus Updated</font>";
}
?>
<div class="row">
	<div class="col-sm-12" style="color:orange;">
		<h1 align="center" >Update Complaints Details</h1>
	</div>
</div>
<div class="row">

<div class="col-sm-12">
<form method="post">
<table class="table table-bordered">
	<tr>
		<Th colspan="2"><?php echo @$err;?></Th>
	</tr>
	<tr>
		<th>Complaint Id</th>
		<td><input name="c_id" type="text" class="form-control" value="<?php echo @$_GET['cid'];?>" readonly="true"/></td>
	</tr>
	<tr>
		<th>Status</th>
		<td><textarea name="c_status" style="height:200px" class="form-control"></textarea></td>
	</tr>
		
<tr>
		<td colspan="2" align="center"><input name="add" type="submit" class="btn btn-success"  value="Update Compaint Staus"/></td>
	</tr>		
</table>
</form>
</div>
</div>

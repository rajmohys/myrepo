<?php
include('../dbconfig.php');
	
	$user_id=$_GET['user_id'];
	$status=$_GET['status'];
	if($status)
	{
	mysqli_query($con,"update police_officer SET status='0' where id='$user_id'");
	header('location:dashboard.php?info=show_user');
	}
	else
	{
	mysqli_query($con,"update police_officer SET status='1' where id='$user_id'");
	header('location:dashboard.php?info=show_user');
	}
	
	?>
-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2016 at 11:35 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `law_order`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE IF NOT EXISTS `complaints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crime_type` varchar(50) NOT NULL,
  `crime_date` date NOT NULL,
  `subject` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `Offender_name` varchar(50) NOT NULL,
  `Offender_address` varchar(255) NOT NULL,
  `proof_documents` varchar(255) NOT NULL,
  `witness_name` char(50) NOT NULL,
  `police_station` varchar(50) NOT NULL,
  `user` varchar(100) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `Complaint_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `crime_type`, `crime_date`, `subject`, `details`, `Offender_name`, `Offender_address`, `proof_documents`, `witness_name`, `police_station`, `user`, `ip_address`, `Complaint_date`) VALUES
(2, 'Robery', '2016-06-07', 'aldjl', 'dljfldjlfjl', 'xyz', 'dddd', '', 'abhi', 'delhi', 'sanjeevtech2@gmail.com', '', '2016-06-27 17:35:38'),
(4, 'Robery', '2016-06-07', 'aldjl', 'dljfldjlfjl', 'xyz', 'dddd', '', 'abhi', '', 'sanjeevtech2@gmail.com', '', '2016-06-27 17:35:56'),
(5, 'Robery', '2016-06-07', 'aldjl', 'dljfldjlfjl', 'xyz', 'dddd', '', 'abhi', '', 'sanjeevtech2@gmail.com', '', '2016-06-27 17:36:02'),
(6, 'Robery', '2016-07-13', 'About Theft', 'dlfjkddddddddd', 'abhi', 'Dlfjdlfldfjl\r\nldjfldjfl\r\ndjfl', '', 'xyz', 'delhi', 'rajmohan@gmail.com', '::1', '2016-07-03 10:30:24');

-- --------------------------------------------------------

--
-- Table structure for table `complaint_status`
--

CREATE TABLE IF NOT EXISTS `complaint_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `compaint_id` int(11) NOT NULL,
  `statuss` varchar(255) NOT NULL,
  `police_officer` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`status_id`),
  KEY `compaint_id` (`compaint_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `complaint_status`
--

INSERT INTO `complaint_status` (`status_id`, `compaint_id`, `statuss`, `police_officer`, `date`) VALUES
(3, 2, 'dfddddddddddddddddddddddd', 'abhi9015', '2016-07-02 15:35:12'),
(4, 2, 'aaaaaaaaaaaaaaaa', 'abhi9015', '2016-07-02 15:35:18'),
(5, 2, 'dddddddddddddd', 'abhi9015', '2016-07-02 15:50:26'),
(6, 2, 'dddddddddddddd', 'abhi9015', '2016-07-02 15:51:42'),
(7, 6, 'hello public you will got the solution as soon as posisble', 'abhi9015', '2016-07-03 10:34:07'),
(8, 6, 'dddddddddddddddddddddd\r\ndddddddddddddddddddddddd\r\naaaaaaaaaaaaaaaaaaaaa', 'abhi9015', '2016-07-03 10:34:21');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `mobile`, `email`, `message`) VALUES
(2, 'sanjeev kumar', 9015501897, 'sanjeevtech2@gmail.com', 'dddddddddd');

-- --------------------------------------------------------

--
-- Table structure for table `emergencey_complaint_status`
--

CREATE TABLE IF NOT EXISTS `emergencey_complaint_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `compaint_id` int(11) NOT NULL,
  `statuss` varchar(255) NOT NULL,
  `police_officer` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`status_id`),
  KEY `compaint_id` (`compaint_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `emergency_complaints`
--

CREATE TABLE IF NOT EXISTS `emergency_complaints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crime_type` varchar(50) NOT NULL,
  `crime_date` date NOT NULL,
  `subject` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `Offender_name` varchar(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `Offender_address` varchar(255) NOT NULL,
  `proof_documents` varchar(255) NOT NULL,
  `witness_name` char(50) NOT NULL,
  `police_station` varchar(50) NOT NULL,
  `ip_address` varchar(100) NOT NULL,
  `Complaint_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `mobile`, `email`, `subject`, `message`, `date`) VALUES
(7, 'sanjeev kumar', 9015501897, 'sanjeevtech2@gmail.com', 'hello ', 'hello test', '2016-07-07'),
(8, 'sanjeev kumar', 9015501897, 'sanjeevtech2@gmail.com', 'hello ', 'hello test', '2016-07-07');

-- --------------------------------------------------------

--
-- Table structure for table `people_registration`
--

CREATE TABLE IF NOT EXISTS `people_registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(20) DEFAULT NULL,
  `lname` char(20) DEFAULT NULL,
  `father_name` char(20) DEFAULT NULL,
  `mother_name` char(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pass` varchar(20) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `aadhar` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `gender` char(20) NOT NULL,
  `dob` varchar(40) NOT NULL,
  `image` varchar(100) NOT NULL,
  `otp` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `people_registration`
--

INSERT INTO `people_registration` (`id`, `name`, `lname`, `father_name`, `mother_name`, `email`, `pass`, `mobile`, `aadhar`, `address`, `gender`, `dob`, `image`, `otp`, `status`, `date`) VALUES
(1, 'amit rao ggh', 'Sharma', 'kishan kumar', 'Santosh Sharma', 'sanjeevtech2@gmail.com', '12345', 2147483647, '', 'vijay nagat ghaziabad', 'Boys', '11-aug-1993', '', '', 0, '0000-00-00 00:00:00'),
(2, 'amit rao ggh', 'Kumar', 'agdja agdja', 'jgsfj djadjs', 'k@gmail.com', '12345', 2147483647, '', 'delhi', 'Boys', '14-oct-1995', 'Desert.jpg', '', 0, '0000-00-00 00:00:00'),
(3, 'amit rao ggh', 'gdjsdj', 'asgdjshdj', 'hjdhsjhdjshj', 'm@gmail.com', '12345', 748738478, '', 'noida', 'Boys', '14-july-1993', 'Chrysanthemum.jpg', '', 0, '0000-00-00 00:00:00'),
(4, 'amit rao ggh', 'gsjds', 'hsdh shdj', 'hdfk sdksh', 'n@gmail.com', '12345', 7837, '', 'noida', 'Boys', '10-april-1991', 'Lighthouse.jpg', '', 0, '0000-00-00 00:00:00'),
(5, 'amit rao ggh', 'Sharma', 'kishan kumar', 'Santosh Sharma', 'deepak@gmail.com', '1234567', 2147483647, '', 'vijay Nagar', 'Boys', '11-aug-1993', 'B612-2016-01-29-08-20-53_1454119183887.jpg', '', 0, '0000-00-00 00:00:00'),
(6, 'amit rao ggh', 'kumar', 'gjdj gshdjjs ahsj', 'jshdj jshdjsd', 'amit@gmail.com', '12345', 2147483647, '', 'noida', 'male', '15-aug-1995', 'Desert.jpg', '', 0, '0000-00-00 00:00:00'),
(7, 'raj', 'mohan', 'rajmohan', 'dlkfjl', 'rajmohan@gmail.com', 'raj', 878787878, 'xyz555445', 'Delhi 144\r\n110009', 'male', '16-sep-1994', 'Koala - Copy.jpg', '93db8', 0, '2016-07-03 10:21:52'),
(8, 'a', 'df', 'dfdf', 'dfd', 'a@gmail.com', 'a', 88888888, 'dfd', 'dfdf', 'male', '16-march-1995', 'Lighthouse.jpg', '98f13', 1, '2016-07-03 12:24:54');

-- --------------------------------------------------------

--
-- Table structure for table `police_officer`
--

CREATE TABLE IF NOT EXISTS `police_officer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_alias` varchar(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `police_station` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(75) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `date` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `police_officer`
--

INSERT INTO `police_officer` (`id`, `user_alias`, `Name`, `designation`, `police_station`, `email`, `password`, `mobile`, `date`, `status`) VALUES
(3, 'abhi9015', 'abhi', '', 'delhi', 'abhi@gmail.com', '12345', 9015501898, '2016-04-01 16:59:21', 0),
(4, 'ac8888', 'ac', '', 'Dlhi', 'a@gmail.com', 'd61ab1', 8888888888, '2016-05-06 16:04:55', 0),
(5, 'deep8888', 'deepa', '', 'Up', 'deepa@gmail.com', '53b3a3', 8888888878, '2016-06-24 17:50:11', 0),
(6, 'deep8888', 'deepak', 'Senior Police officer', 'Mumbai', 'deepak@gmail.com', '12345', 8888888877, '2016-07-03 11:35:18', 0);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaint_status`
--
ALTER TABLE `complaint_status`
  ADD CONSTRAINT `complaint_status_ibfk_1` FOREIGN KEY (`compaint_id`) REFERENCES `complaints` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

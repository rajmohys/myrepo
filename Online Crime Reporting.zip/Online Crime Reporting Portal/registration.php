<?php 
error_reporting(1);
include('dbconfig.php');

extract($_POST);
if(isset($submit))
{
	$que=mysqli_query($con,"select * from people_registration where email='$email' or mobile='$mobile'");
	$row=mysqli_num_rows($que);
	if($row==true)
	{
		$err="<font color='red'>This email or mobile already registered</font>";
	}
	else
	{	
	//sent otp.
	$r=rand(9,99);
	$encrypt=md5($r);
	$otp=substr($encrypt,0,5);
	
	
		$img=$_FILES['image']['name'];
		$dob=$dd."-".$mm."-".$yy;
		$que=mysqli_query($con,"insert into people_registration values('','$name','$lname','$fname','$mname','$email','$password','$mobile','$aadhar','$address','$gen','$dob','$img','$otp','1',now())");
		
		mkdir("images/$email");
		mkdir("images/$email");
		
		move_uploaded_file($_FILES['image']['tmp_name'],"images/$email/".$_FILES['image']['name']);
		
		$err="<h4><font color='green'>You are registered Successfully ! <br/>To activate your account use <strong>OTP : $otp</strong></font></h4>
		<h5>To verify Your OTP <a href='index.php?info=verify_otp'>Click here</a></h5>
		";
		
	}	
}
?>
<form method="post" enctype="multipart/form-data">
<div class="container" style="margin-left:150">
	
	<h3 align="center" style="text-decoration:underline"><font color="#00FF33">Citizen Registreation Form</font></h3>
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2"></div>
		<div class="col-sm-6"><?php echo $err;?></div>
	</div>
	<div class="row" style="margin-top:30px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen First Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="name" class="form-control"/>
			</div>
		</div>
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Last Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="lname" class="form-control"/>
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:20px">
		
		<div class="col-sm-2">
			<label style="font-size:16px">Father Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="fname" class="form-control"/>
			</div>
		</div>
		<div class="col-sm-2" >
			<label style="font-size:16px">Mother Name</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="text" name="mname" class="form-control"/>
			</div>
		</div>
	</div>
	
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Email</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="email" name="email" class="form-control"/>
			</div>
		</div>
		<div class="col-sm-2">
			<label style="font-size:16px">Citizen Password</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="password" name="password" class="form-control"/>
			</div>
		</div>
	</div>
	<div class="row" style="margin-top:20px">
		
	</div>
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2">
			<label style="font-size:16px">Contact No</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<input type="number" name="mobile" class="form-control"/>
			</div>
		</div>
		<div class="col-sm-2">
					<label style="font-size:16px">Select Gender</label>
				</div>
				<div class="col-sm-3">
					Male<input type="radio" name="gen" value="male">
					Female<input type="radio" name="gen" value="female"/> 
				</div>
	</div>
	<div class="row" style="margin-top:20px">
		<div class="col-sm-2">
			<label style="font-size:16px">Address</label>
		</div>
		<div class="col-sm-3">
			<div class="input-group">
				<textarea name="address" rows="5" cols="25"></textarea>
			</div>
		</div>
		<div class="col-sm-2">
					<label style="font-size:16px;margin-top:30px">Select DOB</label>
				</div>
				<div class="col-sm-1" style="margin-top:30px">
					<select name="dd" class="form-control">
						<option selected="selected" disabled="disabled">dd</option>
						<?php
						for($i=1;$i<=31;$i++)
						{
							echo "<option>".$i."</option>";
						}
						?>
					</select>
				</div>
					<div class="col-sm-1" style="margin-top:30px">
					<select name="mm" class="form-control">
						<option selected="selected" disabled="disabled">mm</option>
						<?php
						$arr=array("jan","feb","march","april","may","june","july","aug","sep","oct","nov","dec");
						for($i=0;$i<count($arr);$i++)
						{
							echo "<option>".$arr[$i]."</option>";
						}
						?>
					</select>
				</div>
				<div class="col-sm-1" style="margin-top:30px">
					<select name="yy" class="form-control">
						<option selected="selected" disabled="disabled">yy</option>
						<?php
						for($i=1980;$i<=2016;$i++)
						{
							echo "<option>".$i."</option>";
						}
						?>
					</select>
			</div>
			
			
	</div>
	
			
				<div class="row" style="margin-top:20px">
					<div class="col-sm-2">
						<label style="font:size:16px">Upload Pic</label>
					</div>
					<div class="col-sm-3">
						<div class="input-group">
							<input type="file" name="image"/>
						</div>
					</div>
					
					<div class="col-sm-2">
						<label style="font:size:16px">Aadhar No</label>
					</div>
					<div class="col-sm-3">
						<div class="input-group">
							<input type="text" name="aadhar" required/>
						</div>
					</div>
				</div>
							<div class="row" style="margin-top:20px">
				
	<div class="row" style="margin-top:20px;margin-bottom:60px">
		<div class="col-sm-5"></div>
		<input type="submit" name="submit" value="Register Me" class="btn btn-info"/>
	</div>
</div>
</form>